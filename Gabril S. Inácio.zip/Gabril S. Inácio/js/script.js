// Rolagem suave para os links internos
function ativarRolagemSuave() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const destino = document.querySelector(this.getAttribute('href'));
      if (destino) {
        destino.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Efeito de aparecer ao rolar
function observarElementos() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visivel');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.card, .intro, section h2').forEach(el => {
    el.classList.add('oculto');
    observer.observe(el);
  });
}

// Saudação com nome (uma vez por navegador)
function boasVindas() {
  const nomeSalvo = localStorage.getItem("visitante");
  if (!nomeSalvo) {
    const nome = prompt("Olá! Qual seu nome?");
    if (nome) {
      localStorage.setItem("visitante", nome);
      alert(`Bem-vindo(a), ${nome}! Explore meu portfólio :)`);
    }
  } else {
    window.alert(`Bem-vindo novamente, ${nomeSalvo}`);
  }
}

// Inicialização geral
document.addEventListener("DOMContentLoaded", function () {
  ativarRolagemSuave();
  observarElementos();
  boasVindas();
});

document.querySelectorAll("section").forEach((sec) => {
  sec.classList.add("visivel");
});
